'use strict';

/* Filters */

var appFilters = angular.module('appFilters', []);
